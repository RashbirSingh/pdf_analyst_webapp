from django.apps import AppConfig


class PdfscannerConfig(AppConfig):
    name = 'pdfscanner'
