#define REDIS_GIT_SHA1 "828544a3"
#define REDIS_GIT_DIRTY "     183"
#define REDIS_BUILD_ID "Rashbirs-Air-1597610070"
